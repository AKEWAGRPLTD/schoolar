<?php 
include 'db_connect.php'; 

?>
<div class="container-fluid">
    <form action="stkpay.php" method="POST">
        
        <div class="form-group">
            <label for="" class="control-label">Tenantno: </label>
            <input type="number" class="form-control" name="tenantno">
        </div>
        <div class="form-group">
            <label for="" class="control-label">PhoneNumber: </label>
            <input type="number" class="form-control" name="phonenumber" >
        </div>
        <div class="form-group">
            <label for="" class="control-label">Amount Paid: </label>
            <input type="number" class="form-control text-right" step="any" name="amount">
        </div>
        <div class="form-group">
            <input type="submit" name="submit"  value="Check Out" >
        </div>
</div>
    </form>
</div>

