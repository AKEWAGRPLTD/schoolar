<?php
include 'db_connect.php'; 

/*namespace App\Http\Controllers;*/

use App\Models\callback;
use App\Models\CompletedTransaction;
use App\Models\Contribution;
use App\Models\PendingTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContributionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $all = Contribution::all();
        return response()->json(['success' => true, 'message' => 'fundraiser list generated successfully.' ,"list" => $all]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function pay( Request $request)
    {
       // get the Oauth Bearer access Token from safaricom
       //dd(int($request->amount));

       $rules =
           ['amount'=> 'required|integer',
           'phone'=>'required|integer',
           'id'=>'required|integer'
           ]
       ;

       $input     = $request->only('amount','phone', 'id');
       $validator = Validator::make($input, $rules);

       if ($validator->fails()) {
           return response()->json(['success' => false, 'error' => $validator->messages()]);
       }

       $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
      // $url = 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

       $curl = curl_init();
       curl_setopt($curl, CURLOPT_URL, $url);
       $credentials = base64_encode('D5VGIIfdrsmTHv7dCwGyo4hubU2YFFxN:XelQksS4JcMXfVMI');
       curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Basic '.$credentials)); //setting a custom header
       curl_setopt($curl, CURLOPT_HEADER, false);
       curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

       $curl_response = curl_exec($curl);

       $responce = json_decode($curl_response)->access_token;
       //dd($responce["access_token"]);
       //dd($responce->access_token);
       $accessToken = $responce; // access token here


       //mpesa user credentials
       $mpesaOnlineShortcode = "174379";
       $BusinessShortCode = $mpesaOnlineShortcode;
       $partyA = $request->phone;
       $partyB = $BusinessShortCode;
       $phoneNumber = $partyA;
       $mpesaOnlinePasskey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";
       date_default_timezone_set('Africa/Nairobi');
       $timestamp =  date('YmdHis');
       $amount = $request->amount;
       $contribution = $request->id;
       $dataToEncode = $BusinessShortCode.$mpesaOnlinePasskey.$timestamp;
       //dd($dataToEncode);
       $password = base64_encode($dataToEncode);
       //dd($password);

       //payment request to safaricom

       $url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
       //$url = 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

       $curl = curl_init();
       curl_setopt($curl, CURLOPT_URL, $url);
       curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$accessToken)); //setting custom header


       $curl_post_data = array(
           'BusinessShortCode' => $BusinessShortCode,
           'Password' => $password,
           'Timestamp' => $timestamp,
           'TransactionType' => 'CustomerPayBillOnline',
           'Amount' =>$amount,
           'PartyA' => $partyA,
           'PartyB' => $partyB,
           'PhoneNumber' => $partyA,
           'AccountReference'=>$contribution,
           'CallBackURL' => 'https://msaadaproject.herokuapp.com/api/v2/74aqaGu3sd4/callback',
           'TransactionDesc' => 'DONATING'
       );

       $data_string = json_encode($curl_post_data);

       curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($curl, CURLOPT_POST, true);
       curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);

       $curl_response = curl_exec($curl);
   // print_r($curl_response);

       ///dd($curl_response);
        $data = json_decode($curl_response);

//adding amount
        $contributionUpdate = Contribution::where('id', $contribution)->first();
        $contributionUpdate->amount = $contributionUpdate->amount + $amount;
        $contributionUpdate->save();
        //updating pending transaction table
        $pending = new PendingTransaction();
       $pending->CheckoutRequestID = $data->CheckoutRequestID;
        $pending->phone = $partyA;
        $pending->amount = $amount;
        $pending->contributionId = $contribution;
        $pending->save();

            return response()->json(['responceStatusCode'=>'200' ,'data'=>[
           'message'=>"Request accepted from safaricom, pin prompt sent successfully",
           'expectedAction' => 'query the callback api endpoint to update the UI',
           'callbackinfo'=>$curl_response, // ->CheckoutRequestID
       ]]);


}


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function callback(Request $request)
    {
        $MerchantRequestID = $request->Body['stkCallback']['MerchantRequestID'];
        $CheckoutRequestID = $request->Body['stkCallback']['CheckoutRequestID'];
        $ResultCode = $request->Body['stkCallback']['ResultCode'];
        $ResultDesc = $request->Body['stkCallback']['ResultDesc'];
        $Amount = $request->Body['stkCallback']['CallbackMetadata']['Item']['0']['Value'];
        $MpesaReceiptNumber = $request->Body['stkCallback']['CallbackMetadata']['Item']['1']['Value'];
        $TransactionDate = $request->Body['stkCallback']['CallbackMetadata']['Item']['2']['Value'];
        $PhoneNumber = $request->Body['stkCallback']['CallbackMetadata']['Item']['3']['Value'];
        //dd($PhoneNumber);

        $newTransaction = new Callback();
        $newTransaction->MerchantRequestID = $MerchantRequestID;
        $newTransaction->CheckoutRequestID = $CheckoutRequestID;
        $newTransaction->ResultCode = $ResultCode;
        $newTransaction->ResultDesc = $ResultDesc;
        $newTransaction->Amount = $Amount;
        $newTransaction->MpesaReceiptNumber = $MpesaReceiptNumber;
        $newTransaction->TransactionDate = $TransactionDate;
        $newTransaction->PhoneNumber = $PhoneNumber;
        $newTransaction->save();
    //check the pending
        $pending = PendingTransaction::where("CheckoutRequestID", $CheckoutRequestID)->first();
        if($pending != null){
            $T = new CompletedTransaction();
            $T->PhoneNumber = $PhoneNumber;
            $T->Amount = $Amount;
            $T->contributionId = $pending->contributionId;
            $T->save();

        }


        return response()->json(['statusCode'=>"200", 'Data'=>"transactionReceived"]);
    }

   
    
}
